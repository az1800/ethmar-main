// "use client";
// import { useEffect } from "react";
// import { useRouter } from "next/navigation";
// import Footer from "../components/Footer";
// import Header from "../components/Header";

// export default function Home() {
//   const router = useRouter();

//   useEffect(() => {
//     if (typeof window !== "undefined") {
//       router.push("https://ethmarspp.stuclubs.com/home");
//     }
//   }, [router]);

//   return null; // Prevent rendering while redirecting
// }
"use client";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useState } from "react";

// Figma assets
const imgGroup568 =
  "https://www.figma.com/api/mcp/asset/51bcae13-4fb7-4343-a504-815595478858";
const imgVector8 =
  "https://www.figma.com/api/mcp/asset/3ae8303b-a27b-4fad-bdf1-303348bc4f8a";
const imgGroup565 =
  "https://www.figma.com/api/mcp/asset/a69e8de4-4b9b-4832-baac-f675b802a651";
const imgGroup566 =
  "https://www.figma.com/api/mcp/asset/3b3712f5-217f-40de-a1e3-fb53b9ff1039";
const imgGroup567 =
  "https://www.figma.com/api/mcp/asset/0d49cb1d-f73d-4595-a33a-7772964284a1";
const imgArrow3 =
  "https://www.figma.com/api/mcp/asset/9babb3ee-6f7f-4e01-94b3-e8991c58c113";

const partnerImages = [1, 2, 3, 4, 5];

const achievements = [
  "Road to CFO",
  "Road to CFO",
  "Road to CFO",
  "Road to CFO",
];

const goals = [
  { text: "تعزيز الوعي المالي لدى الطلاب والأفراد", align: "right" as const },
  { text: "تعزيز مهارات التخطيط المالي", align: "left" as const },
  {
    text: "تزويد الطلاب بالأدوات والأساليب اللازمة لتقسيم الدخل",
    align: "right" as const,
  },
];

const stats = [
  { icon: imgGroup565, number: "+100", label: "مستفيد" },
  { icon: imgGroup566, number: "+202", label: "مستفيد" },
  { icon: imgGroup567, number: "+104k", label: "مستفيد" },
];

function ImgPlaceholder({ className }: { className?: string }) {
  return (
    <div
      className={`bg-gray-200 flex items-center justify-center ${className ?? ""}`}
    >
      <svg
        className="w-12 h-12 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={1}
          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
        />
      </svg>
    </div>
  );
}

export default function Home() {
  const [partnerIndex, setPartnerIndex] = useState(0);
  const visibleCount = 3;
  const maxIndex = partnerImages.length - visibleCount;

  return (
    <div dir="rtl" className="font-sans overflow-x-hidden">
      {/* ── Hero ── */}
      <div className="relative bg-[#164b20] overflow-hidden">
        <img
          src={imgGroup568}
          alt=""
          aria-hidden
          className="absolute inset-0 w-full h-full object-cover opacity-30 pointer-events-none"
        />
        <div className="relative z-10">
          <Header />
        </div>
        <div className="relative z-10 flex flex-col items-center text-center px-6 py-20 pb-28">
          <h1 className="text-white text-5xl md:text-7xl font-bold leading-tight mb-6">
            مبادرة إثمار المالية
          </h1>
          <p className="text-[#d9d9d9] text-lg max-w-xl leading-relaxed">
            مبادرة مالية تهدف إلى تمكين الطلاب والطالبات من اكتساب المعرفة
            اللازمة لإدارة شؤونهم المالية وخلق مجتمع يتمتع بالوعي المالي | إحدى
            مبادرات برنامج الشراكة الطلابية.
          </p>
        </div>
      </div>

      {/* ── Mission & Vision ── */}
      <div className="relative bg-[rgba(31,104,44,0.6)] overflow-hidden">
        <img
          src={imgVector8}
          alt=""
          aria-hidden
          className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none rotate-180"
        />
        <div className="relative z-10 max-w-6xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-16">
          <div>
            <h2
              className="text-white text-4xl md:text-5xl font-bold mb-6"
              style={{ textShadow: "0px 4px 20px rgba(0,0,0,0.15)" }}
            >
              رسالـــتنا
            </h2>
            <p className="text-white text-lg leading-relaxed">
              تمكين الطلاب والطالبات من اكتساب المعرفة والمهارات اللازمة لإدارة
              شؤونهم المالية , وخلق مجتمع يتمتع بالوعي المالي.
            </p>
          </div>
          <div className="text-right">
            <h2
              className="text-white text-4xl md:text-5xl font-bold mb-6"
              style={{ textShadow: "0px 4px 20px rgba(0,0,0,0.15)" }}
            >
              رؤيتــــنا
            </h2>
            <p className="text-white text-lg leading-relaxed">
              أن نكون روادًا في مجال التوعية المالية , ملهمين للجيل الصاعد
              بتمكينهم من إتخاذ قرارات مالية سليمة, ودعمهم لتحقيق الاستقلال
              المالي.
            </p>
          </div>
        </div>
      </div>

      {/* ── Stats ── */}
      <div className="bg-[#f3f5f8] py-20 px-6">
        <h2 className="text-center text-[#1f682c] text-4xl md:text-5xl font-bold mb-14">
          إثمار في أرقام
        </h2>
        <div className="max-w-4xl mx-auto grid grid-cols-3 gap-6 text-center">
          {stats.map((stat, i) => (
            <div key={i} className="flex flex-col items-center gap-3">
              <img
                src={stat.icon}
                alt=""
                aria-hidden
                className="h-24 md:h-32 object-contain"
              />
              <span className="text-[#1f682c] text-5xl md:text-7xl font-bold leading-none">
                {stat.number}
              </span>
              <span className="text-[#1f682c] text-xl md:text-2xl font-medium">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* ── Goals ── */}
      <div className="bg-white py-20 px-6">
        <h2 className="text-center text-[#1f682c] text-4xl md:text-5xl font-bold mb-16">
          أهدافنــا
        </h2>
        <div className="max-w-4xl mx-auto flex flex-col gap-14">
          {goals.map((goal, i) => (
            <div
              key={i}
              className={`flex flex-col ${goal.align === "left" ? "items-start" : "items-end"}`}
            >
              <p className="text-[#1f682c] text-2xl md:text-3xl font-medium mb-3 max-w-lg text-right">
                {goal.text}
              </p>
              <div className="h-0.5 w-72 md:w-96 bg-[#1f682c] opacity-70 rounded-full" />
            </div>
          ))}
        </div>
      </div>

      {/* ── Partners ── */}
      <div className="bg-[#f3f5f8] py-20 px-6">
        <h2 className="text-center text-[#1f682c] text-4xl md:text-5xl font-bold mb-4">
          شركاء النجاح
        </h2>
        <div className="flex justify-center mb-8 opacity-30 pointer-events-none">
          <img
            src={imgArrow3}
            alt=""
            aria-hidden
            className="w-full max-w-3xl object-contain"
            style={{ transform: "rotate(174deg)" }}
          />
        </div>
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setPartnerIndex((i) => Math.min(maxIndex, i + 1))}
              disabled={partnerIndex >= maxIndex}
              className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1f682c] text-white text-xl flex items-center justify-center disabled:opacity-30 hover:bg-[#164b20] transition"
              aria-label="التالي"
            >
              ‹
            </button>
            <div className="flex-1 overflow-hidden">
              <div
                className="flex gap-4 transition-transform duration-300"
                style={{ transform: `translateX(${partnerIndex * 33.333}%)` }}
              >
                {partnerImages.map((_, i) => (
                  <div key={i} className="flex-shrink-0 w-1/3">
                    <ImgPlaceholder className="w-full aspect-video rounded-2xl" />
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={() => setPartnerIndex((i) => Math.max(0, i - 1))}
              disabled={partnerIndex <= 0}
              className="flex-shrink-0 w-10 h-10 rounded-full bg-[#1f682c] text-white text-xl flex items-center justify-center disabled:opacity-30 hover:bg-[#164b20] transition"
              aria-label="السابق"
            >
              ›
            </button>
          </div>
        </div>
      </div>

      {/* ── Achievements ── */}
      <div className="bg-white py-20 px-6">
        <h2 className="text-center text-[#1f682c] text-4xl md:text-5xl font-bold mb-14">
          أنجازات
        </h2>
        <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-8">
          {achievements.map((title, i) => (
            <div key={i} className="flex flex-col gap-3">
              <ImgPlaceholder className="w-full aspect-video rounded-2xl" />
              <p className="text-[#1f682c] text-2xl font-semibold pr-1">
                {title}
              </p>
            </div>
          ))}
        </div>
        <div className="max-w-4xl mx-auto mt-12">
          <button className="w-full bg-[#164b20] text-white text-2xl md:text-3xl font-medium py-5 rounded-2xl hover:bg-[#1f682c] transition">
            عرض الكل
          </button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
